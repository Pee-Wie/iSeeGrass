-- iSeeGrass catalog expansion
-- Run this against the existing `iseegrass` database BEFORE running import-seagrass-catalog.mjs.
-- Back up the database first. This migration adds fields used by SEAGRASS_SPECIES.

ALTER TABLE seagrass_catalog
    ADD COLUMN habitat TEXT DEFAULT NULL AFTER region,
    ADD COLUMN depth VARCHAR(80) DEFAULT NULL AFTER habitat,
    ADD COLUMN leaf_shape VARCHAR(180) DEFAULT NULL AFTER depth,
    ADD COLUMN leaf_length VARCHAR(100) DEFAULT NULL AFTER leaf_shape,
    ADD COLUMN color VARCHAR(100) DEFAULT NULL AFTER leaf_length,
    ADD COLUMN status_color VARCHAR(10) DEFAULT NULL AFTER iucn_status,
    ADD COLUMN ph_regions JSON DEFAULT NULL AFTER status_color,
    ADD COLUMN fun_fact TEXT DEFAULT NULL AFTER description,
    ADD COLUMN tags JSON DEFAULT NULL AFTER fun_fact;
